# Transfreezer Insight Suite

Base del sistema web para Transfreezer con frontend en Next.js y backend en FastAPI.

## Inicio rapido (local)

1. Instalar dependencias backend:

```bash
cd backend
python -m pip install --upgrade pip
pip install -r requirements.txt
```

2. Levantar backend:

```bash
cd backend
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

3. Instalar dependencias frontend (en otra terminal):

```bash
cd frontend
npm install
```

4. Levantar frontend:

```bash
cd frontend
npm run dev
```

5. Abrir la app en:

- http://localhost:3000

Para detalles de configuracion consulta:

- frontend/README.md
- backend/README.md

## Estructura

- `frontend/`: dashboard web del usuario final.
- `backend/`: API, carga de modelos y lógica por módulos.

## Módulos comerciales

- `Forecast Operativo`: pronóstico de ingresos y planificación de capacidad.
- `Radar Comercial`: exploración y segmentación comercial con machine learning.
- `Pulso Financiero`: análisis econométrico para soportar decisiones financieras.
- `Asistente de Conocimiento`: análisis de texto y documentos operativos.

## Dónde copiar los modelos entrenados

Copiar los archivos del modelo en:

- `backend/app/modules/forecast_operativo/artifacts/models/`

Formatos recomendados:

- `.pkl`
- `.joblib`

Convención sugerida de nombres:

- `forecast_model.pkl`
- `forecast_model.joblib`
- `forecast_metadata.json`

El backend buscará el archivo según la variable `MODEL_FILE`; si no se define, usará la ruta por defecto del módulo de pronóstico.

## Siguiente paso lógico

Con esta base, lo siguiente es conectar el dashboard del frontend a la API y reemplazar los datos de ejemplo por la salida real del modelo.
