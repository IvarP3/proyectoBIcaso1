# Backend de Transfreezer Insight Suite

API REST construida con FastAPI para servir los módulos de series de tiempo y econometría al frontend.

## Requisitos

- Python 3.10 o superior
- pip actualizado

## Instalación de dependencias

Desde la carpeta backend:

```bash
cd backend
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Si usas entorno virtual (recomendado):

```bash
cd backend
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Variables de entorno

Puedes crear backend/.env (opcional para correr local con modelos ya entrenados).

Ejemplo minimo:

```env
MODEL_FILE=app/modules/forecast_operativo/artifacts/models/transfreezer_modelo_ts.pkl
ECONOMETRIA_MODEL_FILE=app/modules/econometria/artifacts/models/transfreezer_modelo_econometrico_v1.pkl
```

Variables de Snowflake (solo necesarias para capas descriptivas conectadas al DW):

- SNOWFLAKE_ACCOUNT
- SNOWFLAKE_USER
- SNOWFLAKE_PASSWORD
- SNOWFLAKE_WAREHOUSE
- SNOWFLAKE_DATABASE
- SNOWFLAKE_SCHEMA
- SNOWFLAKE_ROLE

## Levantar servidor backend

Desde backend:

```bash
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Endpoints base:

- API base: http://127.0.0.1:8000/api/v1
- Swagger: http://127.0.0.1:8000/docs

## Modelos y rutas

Coloca los modelos entrenados en:

- app/modules/forecast_operativo/artifacts/models/
- app/modules/econometria/artifacts/models/

Formatos soportados:

- .pkl
- .joblib

Si usas nombres distintos, define MODEL_FILE y/o ECONOMETRIA_MODEL_FILE.

## Qué expone este backend

- Series de tiempo: /api/v1/forecast-operativo/*
- Econometría: /api/v1/econometria/*
- Salud: /api/v1/health
