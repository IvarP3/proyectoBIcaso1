from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=('.env', 'backend/.env'),
        env_file_encoding='utf-8',
        extra='ignore'
    )

    app_name: str = 'Transfreezer Insight Suite'
    cors_origins: list[str] = ['http://localhost:3000']
    model_file: str = 'app/modules/forecast_operativo/artifacts/models/transfreezer_modelo_ts.pkl'
    model_dir: str = 'app/modules/forecast_operativo/artifacts/models'
    econometria_model_file: str = 'app/modules/econometria/artifacts/models/transfreezer_modelo_econometrico_v1.pkl'
    econometria_model_dir: str = 'app/modules/econometria/artifacts/models'
    default_forecast_horizon: int = 6
    snowflake_account: str | None = None
    snowflake_user: str | None = None
    snowflake_password: str | None = None
    snowflake_warehouse: str | None = None
    snowflake_database: str | None = None
    snowflake_schema: str | None = None
    snowflake_role: str | None = None
    snowflake_query_timeout_seconds: int = 60

    @property
    def resolved_model_path(self) -> Path:
        return Path(self.model_file)

    def has_snowflake_credentials(self) -> bool:
        required_values = [
            self.snowflake_account,
            self.snowflake_user,
            self.snowflake_password,
            self.snowflake_warehouse,
            self.snowflake_database,
            self.snowflake_schema,
            self.snowflake_role
        ]
        return all(required_values)


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
