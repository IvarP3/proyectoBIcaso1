# Asistente Inteligente

Nombre técnico interno (`asistente_inteligente`) reservado para el futuro módulo de análisis de texto, documentos y consulta inteligente (PLN).

## Propósito previsto

- Leer y resumir documentos operativos.
- Buscar conocimiento en reportes y manuales.
- Responder consultas del usuario sobre contenido interno.

## Estado actual

- No implementado todavía.
- No expone endpoints todavía.
- No requiere modelos en disco todavía.

## Nombre comercial visible

Este módulo se mostrará al usuario final como `Asistente Inteligente (PLN)`.

