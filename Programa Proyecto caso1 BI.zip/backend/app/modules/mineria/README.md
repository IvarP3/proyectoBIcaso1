# Minería de Datos

Nombre técnico interno (`mineria`) reservado para el futuro módulo de analítica comercial y machine learning.

## Propósito previsto

- Explorar patrones de clientes, rutas y contratos.
- Segmentar oportunidades comerciales.
- Sugerir prioridades de atención y expansión.

## Estado actual

- No implementado todavía.
- No expone endpoints todavía.
- No requiere modelos en disco todavía.

## Nombre comercial visible

Este módulo se mostrará al usuario final como `Mermas y Siniestros (Minería de datos)`.

