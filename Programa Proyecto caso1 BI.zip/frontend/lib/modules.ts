export const commercialModules = [
  {
    key: 'radar-comercial',
    internalName: 'mineria',
    commercialName: 'Mermas y Siniestros (Minería de datos)',
    description: 'Exploración de patrones de clientes, rutas y contratos.'
  },
  {
    key: 'forecast-operativo',
    internalName: 'forecast_operativo',
    commercialName: 'Margen de Contratos (Series de tiempo)',
    description: 'Pronóstico mensual de ingresos y margen.'
  },
  {
    key: 'pulso-financiero',
    internalName: 'econometria',
    commercialName: 'Rentabilidad B2B (Econometría)',
    description: 'Predicción operativa y escenarios econométricos para decisiones de rentabilidad.'
  },
  {
    key: 'asistente-conocimiento',
    internalName: 'asistente_inteligente',
    commercialName: 'Asistente Inteligente (PLN)',
    description: 'Consulta y análisis de texto sobre documentos operativos.'
  }
];
