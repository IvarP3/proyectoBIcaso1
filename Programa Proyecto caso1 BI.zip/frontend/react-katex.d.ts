declare module 'react-katex';
